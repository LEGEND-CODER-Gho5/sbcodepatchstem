# CodePatch STEM — SBHS Chapter Website

A responsive, static website starter for the CodePatch STEM South Brunswick High School Chapter.

## Preview locally

You can open `index.html` directly in a browser. For a local development server, run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to Cloudflare Workers

This project includes a basic `wrangler.toml` for Cloudflare Workers Static Assets.

1. Install Node.js and Wrangler (`npm install -g wrangler`).
2. Sign in with `wrangler login`.
3. From this folder, run `wrangler deploy`.
4. Follow the Wrangler output for the deployed `workers.dev` address.

Review the Cloudflare dashboard and deployment output to confirm the final URL. No deployment has been performed by creating this project.

## Before publishing

- Chapter contact email and the supplied Discord, Instagram, and YouTube links are already configured in `index.html`.
- Replace the president portrait placeholder and add member photos after receiving approved images.
- Confirm member names, titles, and descriptions with the chapter before public launch.
- Add any official CodePatch parent-organization links that the chapter wants to publish.

## Project files

- `index.html` — page structure and chapter content
- `styles.css` — visual design and responsive layout
- `script.js` — mobile navigation and current-year footer
- `wrangler.toml` — Cloudflare Workers static-assets configuration
